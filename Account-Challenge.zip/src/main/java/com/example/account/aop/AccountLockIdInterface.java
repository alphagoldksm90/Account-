package com.example.account.aop;

public interface AccountLockIdInterface {
    String getAccountNumber();
}

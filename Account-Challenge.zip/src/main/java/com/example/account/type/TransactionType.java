package com.example.account.type;

public enum TransactionType {
    USE, CANCEL
}

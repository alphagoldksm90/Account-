package com.example.account.type;

public enum TransactionResultType {
    S, F
}
